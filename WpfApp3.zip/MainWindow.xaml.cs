﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Documents;
using System.Numerics.MPFR;

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        private bool opFlag = false;  // true:연산자버튼이 클릭시, false:아님
        private bool enterFlag = false;  // true:엔터버튼이 클릭시, false:아님       
        private bool HexFlag = false;  // true:엔터버튼이 클릭시, false:아님
        private bool opInput = false;  // true:엔터버튼이 클릭시, false:아님

        private string op = "", op2, op_pre;   // 연산자 선언
        string txtExp1 = "", txtExp2 = "";

        ulong opCount = 0;

        BigFloat x1 = new BigFloat("0", precision: 137); // prec 133 = 40digits * 3.3219280948873623478; 137 = 133 + 4(여유분)
        BigFloat x2 = new BigFloat("0", precision: 137);  // prec 133 = 40digits * 3.3219280948873623478;
        BigFloat x3 = new BigFloat("0", precision: 137);  // prec 133 = 40digits * 3.3219280948873623478;
        BigFloat x1_pre = new BigFloat("0", precision: 137);  // prec 133 = 40digits * 3.3219280948873623478;
        BigFloat x2_pre = new BigFloat("0", precision: 137);  // prec 133 = 40digits * 3.3219280948873623478;
        BigFloat memory = new BigFloat("0", precision: 137);  // Mc 클릭시 txtResult 값 저장, Mv 클릭시 paste  */

        private void btnEntryClear_Click(object sender, RoutedEventArgs e)
        {
            txtResult.Text = "0";
            txtExp.Text = "";
            op = "";
            opFlag = false;
        }
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            txtResult.Text = "0";
            enterFlag = true;
        }

        public MainWindow()     // 시작시 초기화
        {
            InitializeComponent();
            TextBlock History = new TextBlock();
            txtExp.Foreground = Brushes.Red;
            op = "+";
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnCopy_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            op2 = btn.Content.ToString();
            string temp;

            switch (op2)
            {
                case "Mc":
                    temp = txtResult.Text.Replace(",", "");
                    BigFloat.Set(memory, temp, 10);
                    btnMcopy.Background = Brushes.YellowGreen;
                    break;

                case "Mp":
                    if (opFlag == false)
                    {
                        txtExp.Text = "";
                        x1 = memory;
                        txtExp1 = x1.ToString();
                        txtExp.Text += x1.ToString();
                    }

                    if (opFlag == true)
                    {
                        x2 = memory;
                        txtExp2 = x2.ToString();
                        txtExp.Text += x2.ToString();

                    }
                    btnMcopy.Background = Brushes.WhiteSmoke;
                    op_cal(op);
                    break;
            }

        }   // Mc-Copy,  Mv-Paste

        private void Button(string Button_No)  //Neumeric 입력 및 계산 update
        {
            if (enterFlag == true)
            {
                enterFlag = false;
                if(txtExp1 != "0.") txtExp1="";
                txtExp2 = "";
                opFlag = false;
            }

            if (enterFlag == false)
            {
                txtExp.Foreground = Brushes.Blue;
                txtExp.Text = "";
            }

            if (opFlag == false)
            {
                txtExp1 += Button_No;
                BigFloat.Set(x1, txtExp1, 10);
            }

            if (opFlag == true)
            {
                txtExp2 += Button_No;
                BigFloat.Set(x2, txtExp2, 10);
            }

            if (opFlag == true) txtExp.Text = txtExp1 + txtExp2 + " ";
            if (opFlag == false) txtExp.Text = txtExp1 + " ";

          
            if (opCount > 1 && op == "*" || opCount > 1 && op == "÷")
            {
                switch (op)
                {
                    case "*":
                        BigFloat.Mul(x2, x2, x2_pre);
                        break;
                    case "÷":
                        BigFloat.Div(x2, x2_pre, x2);
                        break;
                }
                BigFloat.Set(x1, x1_pre);
                op_cal(op_pre);
                return;
            }
            op_cal(op);
        }

        // 숫자 입력
        private void btn_Click(object sender, RoutedEventArgs e)  //Neumeric 입력
        {
            Button btn = sender as Button;
            opInput = false;  // 연산자 입력 후 숫자버튼 누르면 false로 전환
            string btn_No;
            btn_No = btn.Content.ToString();
            Button(btn_No);
        }

        // 소수점 입력

        private void Button_dot()
        {
            if (opFlag == false)
            {
                if (txtExp1.Contains(".")) return;
                if (txtExp1 == "") txtExp1="0";
                txtExp1 += ".";
                txtExp.Text = txtExp1;
            }
          
            if (opFlag == true)
            {
                if (txtExp2.Contains(".")) return;
                if (txtExp2 == "") txtExp2 = "0";
                txtExp2 += ".";
                txtExp.Text = txtExp1 + txtExp2 + " ";
            }
        }     // "." 입력
        private void btndot_Click(object sender, RoutedEventArgs e)
        {
            Button_dot();
        }     // "." 입력

        // Sign 처리
        private void btnsign_Click(object sender, RoutedEventArgs e)
        {

            if (opFlag == false)
            {
                if (txtExp1.Contains("-")) txtExp1 = txtExp1.Replace("-", "");
                else txtExp1 = "-" + txtExp1;
                txtExp.Text = txtExp1;
                BigFloat.Set(x1, txtExp1, 10);

            }

            if (opFlag == true)
            {
                if (txtExp2.Contains("-")) txtExp2 = txtExp2.Replace("-", "");
                else txtExp2 = "-" + txtExp2;
                txtExp.Text = txtExp1 + " " + op + " " + txtExp2;
                BigFloat.Set(x2, txtExp2, 10);
            }
            op_cal(op);
        }    // 부호 +, - 변경

        private void Enter2()
        {
            txtExp.Foreground = Brushes.Red;
            enterFlag = true;
            opFlag = false;
            op = "+";
            opCount = 0;

            txtExp.Text += " =  ";

            
            History.TextAlignment=TextAlignment.Right;
            History.Inlines.Add(txtExp.Text);
            History.Inlines.Add("\n");
            History.Inlines.Add(new Run(txtResult.Text) { FontWeight = FontWeights.Bold, FontSize = 12, Foreground = Brushes.Purple });
            History.Inlines.Add("  \n\n");

            BigFloat.Set(x1, "0", 10);
            BigFloat.Set(x2, "0", 10);
            txtExp1 = "";
            txtExp2 = "";
        }
        private void Enter()
        {
            if (enterFlag == true) return;
            Enter2();
        }    // 엔터키 입력시 수식 및 결과값 확정, History에 저장


        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            Enter();
        }    // 엔터키 입력시 수식 및 결과값 확정, History에 저장

        private void Operator(string op)
        {
            if (enterFlag == true && opFlag == false)
            {
                enterFlag = false;
                opFlag = true;
                txtExp1 = txtExp.Text;
                txtExp2 = "";

                BigFloat.Set(x1, txtResult.Text, 10);
            }
            opFlag = true;
        }          // 연산자 입력시

        private void btnFun2_Click(object sender, RoutedEventArgs e)
        {
            opFlag = true;
            opCount += 1;

            if (op == "+" || op == "-" || op == "*" || op == "÷")    // 후방의 곱셈, 나눗셈을 대비하여 전전항 임시 저장
            {
                BigFloat.Set(x1_pre, x1);
                op_pre = op;
            }


            if (opCount > 1)         // 후방의 곱셈, 나눗셈을 대비하여 전항 임시 저장
            {
                BigFloat.Set(x2_pre, x2);
            }


            Button btn = sender as Button;
            op = btn.Content.ToString();

            if (opInput == true)   // 연산자(+,-,*,÷) 반복 입력시 지막 연산자로 대체 
            {
                txtExp1 = txtExp1.Substring(0, txtExp1.Length - 3);
                txtExp1 += " " + op + " ";
                txtExp.Text = txtExp1;
                return;
            }

            if (opFlag == false) txtExp1 = txtExp1 + " ";
            if (opFlag == true)
            {
                if (op == "xⁿ") txtExp1 += "^" + txtExp2;
                if (op == "ⁿ√") txtExp1 += "";
                if (op != "ⁿ√" && op != "xⁿ")
                {
                    txtExp1 += " " + txtExp2 + " " + op + " ";
                    txtExp2 = "";
                }
            }

            txtExp.Text = txtExp1;

            BigFloat.Set(x1, x3);

            if (enterFlag == true)
            {
                enterFlag = false;
                txtExp.Text = "";
            }
            Operator(op);

            opInput = true;  // 연산자 입력되면 True로 전환           

        }          // 연산자 입력시

        private void op_cal(string op)
        {
            Int64 a1, a2, a3;
            switch (op)
            {
                case "+":
                    BigFloat.Add(x3, x1, x2);
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "-":
                    BigFloat.Sub(x3, x1, x2);
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "*":
                    BigFloat.Mul(x3, x1, x2);
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "÷":
                    BigFloat.Div(x3, x1, x2);
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "mod":
                    a1 = x1.ToInt64();
                    a2 = x2.ToInt64();
                    a3 = (int)a1 % (int)a2;
                    x3.Set(a3);
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "xⁿ":
                    BigFloat.Pow(x3, x1, x2);
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "ⁿ√":
                    ulong long_temp;
                    long_temp = ulong.Parse(txtExp1);
                    BigFloat.Root(x3, x2, long_temp);
                    txtExp.Text = txtExp1 + " " + "yRoot" + " " + txtExp2;
                    txtResult.Text = x3.ToString("d36");
                    break;

            }
            txtResult.Text = Display(txtResult.Text);
        }                                  // 기본 연산자 수행

        private void btnConst_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            op = btn.Content.ToString();

            switch (op)
            {
                case "π":
                    x3.ConstPi();
                    txtResult.Text = x3.ToString("d36");
                    enterFlag = true;
                    if (txtExp1 != "")
                    {
                        BigFloat.Mul(x3, x1, x3);
                        txtExp.Text = txtExp1 + "π ";
                        txtExp1 = "";
                        txtExp2 = "";
                    }
                    else txtExp.Text = " π ";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "e":
                    x3 = new BigFloat("2.71828182845904523536028747135266249775724709369995", precision: 133);  // 
                    txtResult.Text = x3.ToString("d36");
                    enterFlag = true;
                    if (txtExp1 != "")
                    {
                        BigFloat.Mul(x3, x1, x3);
                        txtExp.Text = txtExp1 + "e ";
                        txtExp1 = "";
                        txtExp2 = "";
                    }
                    else txtExp.Text = " e ";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "%":
                    txtExp.Text = txtExp1 + txtExp2 + "%";
                    BigFloat.Div(x3, x3, (double)100);
                    txtResult.Text = x3.ToString("d36");
                    enterFlag = true;
                    break;

            }

            txtResult.Text = Display(txtResult.Text);
            Enter2();

            op = "+";
        }     // pi, e 등 상수 함수

        private void btnFun1_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (txtExp1 == "") return;
            op = btn.Content.ToString();

            if (enterFlag == true) x3 = new BigFloat(txtResult.Text, precision: 137);
            txtExp.Text = " " + op + "( ";
            opFlag = true;

            switch (op)     // 삼각함수ian 입력값
            {
                case "sin":
                    BigFloat.Sin(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "cos":
                    BigFloat.Cos(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "tan":
                    BigFloat.Tan(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "asin":
                    BigFloat.Asin(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "acos":
                    BigFloat.Acos(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "atan":
                    BigFloat.Atan(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "sinh":
                    BigFloat.Sinh(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "cosh":
                    BigFloat.Cosh(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "tanh":
                    BigFloat.Tanh(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "asinh":
                    BigFloat.Asinh(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "acosh":
                    BigFloat.Acosh(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "atanh":
                    BigFloat.Atanh(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "√":
                    BigFloat.Sqrt(x3, x1);
                    txtExp.Text = op + "(" + txtExp1 + ")";
                    if (enterFlag == true) txtExp1 = " " + op + "( ";
                    if (enterFlag == false) txtExp1 = op + "(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "x²":
                    BigFloat.Sqr(x3, x1);
                    txtExp.Text = "(" + txtExp1 + ")" + "²";
                    if (enterFlag == true) txtExp1 = " " + "²" + "( ";
                    if (enterFlag == false) txtExp1 = "(" + txtExp1 + ")" + "²";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "2ⁿ":
                    BigFloat.Set(x2, 2);
                    BigFloat.Pow(x3, x2, x1);
                    txtExp.Text = "2^" + txtExp1;
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "10ⁿ":
                    BigFloat.Set(x2, 10);
                    BigFloat.Pow(x3, x2, x1);
                    txtExp.Text = "10^" + txtExp1;
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "n!":
                    ulong long_temp;
                    long_temp = ulong.Parse(txtExp1);
                    BigFloat.Fac(x3, long_temp);
                    txtExp.Text = txtExp1 + "!";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "log₂":
                    BigFloat.Log2(x3, x1);
                    txtExp.Text = "log2(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "log10":
                    BigFloat.Log10(x3, x1);
                    txtExp.Text = "log10(" + txtExp1 + ")";
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "eⁿ":
                    BigFloat.Set(x2, "2.71828182845904523536028747135266249775724709369995", 10);// 
                    BigFloat.Pow(x3, x2, x1);
                    txtExp.Text = "e^" + txtExp1;
                    txtResult.Text = x3.ToString("d36");
                    break;
                case "1/x":
                    BigFloat.Set(x3, "1.0", 10);
                    BigFloat.Set(x2, txtExp1, 10);
                    BigFloat.Div(x3, x3, x2);
                    txtExp.Text = "1/" + txtExp1;
                    txtResult.Text = x3.ToString("d36");
                    break;
            }

            txtResult.Text = Display(txtResult.Text);
            Enter2();

        }        // 삼각함수 등

        private void Number_Delete()
        {
            if (opFlag == false)
            {
                txtExp1 = txtExp1.Substring(0, txtExp1.Length - 1);
                BigFloat.Set(x1, txtExp1, 10);
                txtExp.Text = txtExp1 + " ";
            }
            if (opFlag == true)
            {
                txtExp2 = txtExp2.Substring(0, txtExp2.Length - 1);
                BigFloat.Set(x2, txtExp2, 10);
                txtExp.Text = txtExp1 + " " + txtExp2 + " ";
            }
            op_cal(op);
        } // Back space 기능


        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Number_Delete();
        }


        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            string number;
            int key_value;

            key_value = (int)e.Key;

            if (key_value > 73 && key_value < 85)
            {
                number = (key_value - 74).ToString();
                Button(number);
                return;
            }

            if (e.Key == Key.Decimal) { Button_dot(); return; }
            if (e.Key == Key.Delete) { Number_Delete(); return; }

            if (e.Key == Key.Add) { op = "+"; Operator(op); return; }
            if (e.Key == Key.Subtract) { op = "-"; Operator(op); return; }
            if (e.Key == Key.Multiply) { op = "*"; Operator(op); return; }   // 내 PC에서 미작동
            if (e.Key == Key.Divide) { op = "÷"; Operator(op); return; }

            if ((Keyboard.IsKeyDown(Key.LeftCtrl) && Keyboard.IsKeyDown(Key.V)))

            {
                if (opFlag == false)
                {
                    txtExp1 = Clipboard.GetText();
                    BigFloat.Set(x1, txtExp1, 10);
                    txtExp.Text = txtExp1;
                }

                if (opFlag == true)
                {
                    txtExp2 = Clipboard.GetText();
                    BigFloat.Set(x2, txtExp2, 10);   // 정상 작동
                    txtExp.Text = txtExp1 + " " + op + " " + txtExp2;
                }
                op_cal(op);
            }
        }   // 숫자키, 

        private void btnHEX_Click(object sender, RoutedEventArgs e)
        {
            if (HexFlag == false)
            {
                HexFlag = true;
                HexResult.Foreground = Brushes.DarkOliveGreen;
                HexResult.Text = " Hex-Dec : " + x3.ToString("b16") + " ";
                return;
            }

            if (HexFlag == true) HexFlag = false;
            HexResult.Foreground = Brushes.IndianRed;
            HexResult.Text = " Hex-Decimal :   ";
        }       // 16진수로 출력 클릭


        private string Display(string str)
        {
            long digit_temp, digits = 36;
            long str_start = 0, str_length, E_position, exp, mod3 = 0;
            string str_exp, sign, str_temp = "", str_no = "";


            E_position = str.LastIndexOf("E");
            str_length = str.Length;
            str_exp = str.Substring((int)E_position, (int)(str_length - E_position));
            exp = long.Parse(str_exp.Substring(2, (int)(str_length - E_position - 2)));

            if (str_exp.Substring(1, 1) == "-") exp = -exp;
            if (str.Substring(0, 1) == "-")
            { str_start = 3; sign = "-"; }
            else
            { str_start = 2; sign = ""; }

            str_no = "";

            if (exp < 0 || -exp >= digits)

            {
                if (exp > -7 && exp < 0)
                {
                    str_no += "0.";
                    for (long i = 0; i > exp; i--) str_no += "0";
                    str_no += str.Substring((int)str_start, (int)(E_position - str_start));
                }
                else
                    str_no = str;    // exp < 0 일때는 스트링 그대로 표시
            }

            if (exp == 0) str_no = str.Substring(0, (int)E_position);  // exp == 0 일때는 스트링에서 지수 부분만 제거

            if (exp == 1) // exp == 1 일때는 스트링에서 지수 부분 및 왼쪽으로 1자리수 시프트
            {
                str_no += sign;
                str_no += str.Substring((int)str_start, 1);
                if (E_position - 1 > str_start) str_no += ".";
                str_no += str.Substring((int)str_start + 1, (int)(E_position - str_start - 1));
            }

            if (exp > 1 && exp < digits)   // exp > 1 일때는 exp>E-Position, exp<E-Position로 분리
            {
                digit_temp = E_position - str_start;

                if (digit_temp < exp)
                {
                    for (long i = 0; i < digit_temp; i++) str_temp += str.Substring((int)(str_start + i), 1);
                    for (long i = digit_temp; i < exp; i++) str_temp += "0";
                    str_length = str_temp.Length;
                    mod3 = str_length % 3;
                    str_no = "";

                    for (long i = 0; i < str_length; i++)
                    {
                        str_no += str_temp.Substring((int)i, 1);
                        if ((i + 1) % 3 == mod3 && i < (exp - 1)) str_no += ",";
                    }
                }

                if (digit_temp >= exp)   // exp >= (E_position - str_start)
                {
                    str_no = "";
                    mod3 = exp % 3;
                    for (long i = 0; i < exp; i++)
                    {
                        str_no += str.Substring((int)(i + str_start), 1);
                        if ((i + 1) % 3 == mod3 && i < (exp - 1)) str_no += ",";
                    }
                    if (E_position - str_start > exp) str_no += ".";
                    str_no += str.Substring((int)(exp + str_start), (int)(digit_temp - exp));
                }
                str_no = sign + str_no;
            }
            if (exp > digits) str_no = str;
            return str_no + " ";
        }                          // 10진수로 출력
    }
}

